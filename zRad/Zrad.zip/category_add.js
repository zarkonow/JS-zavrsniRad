const search = window.location.search;
//console.log(search);
const params = search.split('=');
const id = params[1];
let string = "query=true";
let idValue = string.split('=')[1]; 
let userId = idValue == 'true' ? 1 : 0;
console.log(userId);


document.getElementById('addCategory').addEventListener('click',async function(){
    
const categoryName = document.getElementById('categoryName').value
const categoryImage = document.getElementById('categoryImage').value
console.log(categoryName, categoryImage);

  if (!categoryName || !categoryImage) {
    return alert('Popunite SVa Polja');
    }
  
  const response = await fetch(`http://localhost:3000/categories`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      },
      body: JSON.stringify({
      name: categoryName,
      image: categoryImage,
      }),
    });
    const ads = await response.json();
    console.log(ads);
  
    window.open(`./user.html?id=${userId}`, '_self');

  
})